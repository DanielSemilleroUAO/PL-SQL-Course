CREATE OR REPLACE PROCEDURE hola_mundo
AS
BEGIN
    
    dbms_output.put_line('Hola Mundo');

END;
/